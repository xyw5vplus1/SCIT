clc;clear;
z1 = rand(1000,3)-0.5;
z2 = rand(1000,3)-0.5;
zx  = z1 + z2;
zy  = z1 - z2;