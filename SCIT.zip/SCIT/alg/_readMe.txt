Kernel function verison : SCIT
Neural network version : SCITn